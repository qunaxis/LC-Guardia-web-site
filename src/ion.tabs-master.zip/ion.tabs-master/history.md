![ion.tabs](_tmp/logo-ion-tabs.png)

# Update History

### Version 1.0.2. November 01, 2013
* Fixed bug with setTab method

### Version 1.0.1. October 19, 2013
* Fixed some minor bugs, many code optimisations
* Fixed some bugs in plugin description

### Version 1.0.0. September 15, 2013
* Plugin release

***

Support the plugin:

[![](https://pledgie.com/campaigns/25694.png?skin_name=chrome)](https://pledgie.com/campaigns/25694)
